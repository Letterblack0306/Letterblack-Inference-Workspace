# Letterblack Local Inference Workspace — Static UI Prototype

This is a dependency-free HTML/CSS/JavaScript prototype based on the consolidated product specification.

## Run

Open `index.html` directly, or serve the folder locally:

```powershell
python -m http.server 8088 --directory .
```

Then open `http://localhost:8088`.

## Implemented prototype interactions

- Page navigation
- Workspace customize mode
- Drag/reorder and browser resize handles for widgets
- Widget library drawer
- Add-machine modal with test state
- Any-number machine registry persisted in `localStorage`
- Custom action builder
- Command palette
- Model table
- Context inspector
- Stop-all confirmation flow
- Responsive navigation and inspector

## Scope

This package is UI/UX only. Runtime control, GGUF parsing, machine controllers, APIs, telemetry, and service management are represented as interface states and require backend integration.
