# Letterblack Local Inference Workspace — Phase 5

Phase 5 adds hardware safety and telemetry to the Phase 4 gateway/runtime foundation.

## New capabilities

- GGUF v2/v3 metadata header parsing during recursive model scans.
- Architecture, block count, context length, embedding size, attention heads and KV heads.
- Live NVIDIA GPU telemetry via `nvidia-smi` when available.
- Host memory and platform telemetry using standard-library/OS commands.
- Worker telemetry ingestion through each fixed-action controller `/status` response.
- Model allocation estimates for GPU weights, KV cache, runtime reserve and headroom.
- Confidence and risk states: `safe`, `caution`, `high`, `unknown`.
- Preflight API and default blocking of predicted high-risk launches.
- Explicit `allowUnsafe` acknowledgement for owner overrides.

## New routes

```text
GET  /api/v1/hardware
GET  /api/v1/telemetry
GET  /api/v1/models/{modelId}/allocation
POST /api/v1/runtime/preflight
```

## Run

```powershell
.\run.bat
```

Open `http://127.0.0.1:8088`.

## Test

```powershell
.\test.bat
```

## Accuracy boundary

Allocation results are estimates. A high-confidence estimate requires parsed GGUF architecture metadata and live GPU telemetry. Unknown or incomplete metadata is reported honestly; it is never replaced with fabricated hardware values.
