from __future__ import annotations

import json
import threading
from copy import deepcopy
from pathlib import Path
from typing import Any


DEFAULT_STATE: dict[str, Any] = {
    "schemaVersion": 1,
    "machines": [
        {
            "id": "machine-host",
            "name": "Host",
            "addresses": ["192.168.1.240"],
            "controller": {"scheme": "http", "port": 50053},
            "rpc": {"port": 50052, "enabled": False},
            "paths": {"runtime": "Z:\\LLM_Proxy", "models": "Z:\\LLM_Proxy\\Models"},
            "enabled": True,
            "tags": ["host", "lan"],
            "status": "unknown",
        },
        {
            "id": "machine-worker-01",
            "name": "Worker 01",
            "addresses": ["192.168.1.155"],
            "controller": {"scheme": "http", "port": 50053},
            "rpc": {"port": 50052, "enabled": True},
            "paths": {"runtime": "D:\\Developement\\LLM_Proxy", "models": "D:\\Developement\\LLM_Proxy\\Models"},
            "enabled": True,
            "tags": ["worker", "lan"],
            "status": "unknown",
        },
    ],
    "models": [],
    "profiles": [],
    "jobs": [],
    "logs": [],
    "runtime": {"state": "stopped", "activeModelId": None, "activeProfileId": None},
}


class JsonStore:
    def __init__(self, path: Path):
        self.path = path
        self._lock = threading.RLock()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self._write(DEFAULT_STATE)

    def _read(self) -> dict[str, Any]:
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            backup = self.path.with_suffix(".corrupt.json")
            try:
                self.path.replace(backup)
            except OSError:
                pass
            self._write(DEFAULT_STATE)
            return deepcopy(DEFAULT_STATE)

    def _write(self, state: dict[str, Any]) -> None:
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(state, indent=2), encoding="utf-8")
        temp.replace(self.path)

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return deepcopy(self._read())

    def mutate(self, fn):
        with self._lock:
            state = self._read()
            result = fn(state)
            self._write(state)
            return deepcopy(result)
