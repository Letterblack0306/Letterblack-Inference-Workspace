from __future__ import annotations

import argparse
import json
import mimetypes
import os
import socket
import sys
import threading
import time
import urllib.parse
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from backend.contracts import create_job, envelope, error, new_id, now_ms, validate_machine
    from backend.store import JsonStore
else:
    from .contracts import create_job, envelope, error, new_id, now_ms, validate_machine
    from .store import JsonStore

ROOT = Path(__file__).resolve().parents[1]
WEB_ROOT = ROOT / "web"
CONTRACT_ROOT = ROOT / "contracts"
STORE = JsonStore(ROOT / "data" / "state.json")

CAPABILITIES = {
    "contractVersion": "1.0.0",
    "phase": 1,
    "runtimeMode": "contract-simulation",
    "features": {
        "machineRegistry": True,
        "machineConnectionTest": True,
        "rpcLifecycle": "simulated",
        "modelScanning": "contract-only",
        "profileRegistry": True,
        "runtimeLifecycle": "simulated",
        "jobs": True,
        "logs": True,
        "telemetry": "sample",
        "openAICompatibility": False,
        "ollamaCompatibility": False,
        "arbitraryShell": False,
    },
    "defaultPorts": {"dashboard": 8088, "openai": 1234, "ollama": 11434, "rpc": 50052, "controller": 50053},
}


def add_log(state: dict[str, Any], severity: str, source: str, message: str, **details: Any) -> dict[str, Any]:
    event = {
        "id": new_id("log"),
        "timestamp": now_ms(),
        "severity": severity,
        "source": source,
        "message": message,
        "details": details,
    }
    state["logs"].insert(0, event)
    del state["logs"][500:]
    return event


def simulate_job(job_id: str) -> None:
    def worker():
        phases: list[str] = []
        snap = STORE.snapshot()
        for job in snap["jobs"]:
            if job["id"] == job_id:
                phases = job.get("phases", [])
                break
        if not phases:
            return
        for index, phase in enumerate(phases):
            time.sleep(0.35)
            def update(state):
                for job in state["jobs"]:
                    if job["id"] == job_id:
                        job["state"] = "running"
                        job["phase"] = phase
                        job["progress"] = int((index / max(1, len(phases))) * 100)
                        job["updatedAt"] = now_ms()
                        job["evidence"].append({"phase": phase, "status": "simulated-pass", "timestamp": now_ms()})
                        return job
            STORE.mutate(update)
        def finish(state):
            for job in state["jobs"]:
                if job["id"] == job_id:
                    job["state"] = "succeeded"
                    job["phase"] = "complete"
                    job["progress"] = 100
                    job["updatedAt"] = now_ms()
                    if job["type"] == "runtime.launch":
                        state["runtime"]["state"] = "simulated-ready"
                        state["runtime"]["activeModelId"] = job["target"].get("modelId")
                        state["runtime"]["activeProfileId"] = job["target"].get("profileId")
                    elif job["type"] == "runtime.stop":
                        state["runtime"] = {"state": "stopped", "activeModelId": None, "activeProfileId": None}
                    add_log(state, "info", "jobs", f"Job {job_id} completed in simulation mode.", jobType=job["type"])
                    return job
        STORE.mutate(finish)
    threading.Thread(target=worker, daemon=True).start()


class Handler(BaseHTTPRequestHandler):
    server_version = "LetterblackPhase1/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        sys.stdout.write("[%s] %s\n" % (self.log_date_time_string(), fmt % args))

    def _request_id(self) -> str:
        return self.headers.get("X-Request-ID") or new_id("req")

    def _send_json(self, status: int, payload: dict[str, Any]) -> None:
        body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Request-ID", payload.get("requestId", self._request_id()))
        self.end_headers()
        self.wfile.write(body)

    def _ok(self, data: Any, status: int = 200) -> None:
        self._send_json(status, envelope(data, request_id=self._request_id()))

    def _fail(self, code: str, message: str, status: int = 400, details: Any = None) -> None:
        status_code, payload = error(code, message, status=status, details=details, request_id=self._request_id())
        self._send_json(status_code, payload)

    def _json_body(self) -> Any:
        length = int(self.headers.get("Content-Length", "0"))
        if length > 1_000_000:
            raise ValueError("Payload exceeds 1 MB.")
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        return json.loads(raw.decode("utf-8"))

    def _parts(self) -> list[str]:
        path = urllib.parse.urlparse(self.path).path
        return [urllib.parse.unquote(p) for p in path.strip("/").split("/") if p]

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.send_header("Allow", "GET,POST,PUT,DELETE,OPTIONS")
        self.end_headers()

    def do_GET(self) -> None:
        parts = self._parts()
        if parts[:2] == ["api", "v1"]:
            self._api_get(parts[2:])
        else:
            self._serve_static()

    def do_POST(self) -> None:
        parts = self._parts()
        if parts[:2] != ["api", "v1"]:
            self._fail("ROUTE_NOT_FOUND", "Unknown route.", 404)
            return
        try:
            body = self._json_body()
        except (ValueError, json.JSONDecodeError) as exc:
            self._fail("INVALID_JSON", str(exc), 400)
            return
        self._api_post(parts[2:], body)

    def do_PUT(self) -> None:
        parts = self._parts()
        if parts[:3] != ["api", "v1", "machines"] or len(parts) != 4:
            self._fail("ROUTE_NOT_FOUND", "Unknown route.", 404)
            return
        try:
            body = self._json_body()
        except (ValueError, json.JSONDecodeError) as exc:
            self._fail("INVALID_JSON", str(exc), 400)
            return
        machine_id = parts[3]
        body["id"] = machine_id
        issues = validate_machine(body)
        if issues:
            self._fail("VALIDATION_FAILED", "Machine validation failed.", 422, issues)
            return
        def update(state):
            for index, machine in enumerate(state["machines"]):
                if machine["id"] == machine_id:
                    body.setdefault("status", machine.get("status", "unknown"))
                    state["machines"][index] = body
                    add_log(state, "info", "machines", "Machine updated.", machineId=machine_id)
                    return body
            return None
        result = STORE.mutate(update)
        if result is None:
            self._fail("MACHINE_NOT_FOUND", "Machine was not found.", 404)
        else:
            self._ok(result)

    def do_DELETE(self) -> None:
        parts = self._parts()
        if parts[:3] == ["api", "v1", "machines"] and len(parts) == 4:
            machine_id = parts[3]
            def remove(state):
                before = len(state["machines"])
                state["machines"] = [m for m in state["machines"] if m["id"] != machine_id]
                if len(state["machines"]) != before:
                    add_log(state, "warning", "machines", "Machine removed.", machineId=machine_id)
                    return True
                return False
            if STORE.mutate(remove):
                self._ok({"deleted": machine_id})
            else:
                self._fail("MACHINE_NOT_FOUND", "Machine was not found.", 404)
        else:
            self._fail("ROUTE_NOT_FOUND", "Unknown route.", 404)

    def _api_get(self, parts: list[str]) -> None:
        state = STORE.snapshot()
        if parts == ["capabilities"]:
            self._ok(CAPABILITIES)
        elif parts == ["system", "status"]:
            self._ok({
                "state": "contract-ready",
                "phase": 1,
                "simulation": True,
                "runtime": state["runtime"],
                "counts": {k: len(state[k]) for k in ("machines", "models", "profiles", "jobs")},
                "contractVersion": CAPABILITIES["contractVersion"],
            })
        elif parts == ["machines"]:
            self._ok(state["machines"])
        elif parts == ["models"]:
            self._ok(state["models"])
        elif parts == ["profiles"]:
            self._ok(state["profiles"])
        elif parts == ["jobs"]:
            self._ok(state["jobs"])
        elif len(parts) == 2 and parts[0] == "jobs":
            job = next((j for j in state["jobs"] if j["id"] == parts[1]), None)
            if job:
                self._ok(job)
            else:
                self._fail("JOB_NOT_FOUND", "Job was not found.", 404)
        elif parts == ["logs"]:
            self._ok(state["logs"][:200])
        elif parts == ["telemetry"]:
            self._ok({"state": "sample", "timestamp": now_ms(), "machines": []})
        elif parts == ["openapi.json"]:
            try:
                data = json.loads((CONTRACT_ROOT / "openapi.json").read_text(encoding="utf-8"))
                self._ok(data)
            except OSError:
                self._fail("CONTRACT_MISSING", "OpenAPI contract is missing.", 500)
        else:
            self._fail("ROUTE_NOT_FOUND", "Unknown API route.", 404)

    def _api_post(self, parts: list[str], body: Any) -> None:
        if parts == ["machines"]:
            issues = validate_machine(body)
            if issues:
                self._fail("VALIDATION_FAILED", "Machine validation failed.", 422, issues)
                return
            def add(state):
                if any(m["id"] == body["id"] for m in state["machines"]):
                    return None
                machine = dict(body)
                machine.setdefault("enabled", True)
                machine.setdefault("tags", [])
                machine.setdefault("paths", {})
                machine["status"] = "unknown"
                state["machines"].append(machine)
                add_log(state, "info", "machines", "Machine registered.", machineId=machine["id"])
                return machine
            result = STORE.mutate(add)
            if result is None:
                self._fail("MACHINE_EXISTS", "A machine with this ID already exists.", 409)
            else:
                self._ok(result, 201)
            return
        if len(parts) == 3 and parts[0] == "machines" and parts[2] == "test":
            machine_id = parts[1]
            state = STORE.snapshot()
            machine = next((m for m in state["machines"] if m["id"] == machine_id), None)
            if not machine:
                self._fail("MACHINE_NOT_FOUND", "Machine was not found.", 404)
                return
            address = machine["addresses"][0]
            port = machine["controller"]["port"]
            started = time.monotonic()
            reachable = False
            diagnostic = None
            try:
                with socket.create_connection((address, port), timeout=1.0):
                    reachable = True
            except OSError as exc:
                diagnostic = str(exc)
            latency = round((time.monotonic() - started) * 1000, 2)
            result = {"machineId": machine_id, "reachable": reachable, "latencyMs": latency, "diagnostic": diagnostic, "testedAt": now_ms()}
            def record(state):
                for item in state["machines"]:
                    if item["id"] == machine_id:
                        item["status"] = "reachable" if reachable else "offline"
                        item["lastTest"] = result
                add_log(state, "info" if reachable else "warning", "machines", "Connection test completed.", **result)
                return result
            self._ok(STORE.mutate(record))
            return
        if len(parts) == 4 and parts[0] == "machines" and parts[2] == "rpc" and parts[3] in {"start", "stop"}:
            machine_id, action = parts[1], parts[3]
            state = STORE.snapshot()
            if not any(m["id"] == machine_id for m in state["machines"]):
                self._fail("MACHINE_NOT_FOUND", "Machine was not found.", 404)
                return
            job = create_job(f"rpc.{action}", {"machineId": machine_id}, ["validate", "dispatch", "verify"])
            def add(state):
                state["jobs"].insert(0, job)
                add_log(state, "info", "rpc", f"RPC {action} requested in simulation mode.", machineId=machine_id, jobId=job["id"])
                return job
            STORE.mutate(add)
            simulate_job(job["id"])
            self._ok(job, 202)
            return
        if parts == ["models", "scan"]:
            job = create_job("models.scan", body, ["validate-sources", "enumerate", "register"])
            STORE.mutate(lambda state: state["jobs"].insert(0, job) or job)
            simulate_job(job["id"])
            self._ok(job, 202)
            return
        if parts == ["profiles"]:
            if not isinstance(body, dict) or not body.get("id") or not body.get("name"):
                self._fail("VALIDATION_FAILED", "Profile id and name are required.", 422)
                return
            def add(state):
                if any(p["id"] == body["id"] for p in state["profiles"]):
                    return None
                profile = dict(body)
                profile.setdefault("schemaVersion", 1)
                profile.setdefault("validationState", "unknown")
                state["profiles"].append(profile)
                return profile
            result = STORE.mutate(add)
            if result is None:
                self._fail("PROFILE_EXISTS", "A profile with this ID already exists.", 409)
            else:
                self._ok(result, 201)
            return
        if parts == ["runtime", "launch"]:
            if not isinstance(body, dict) or not body.get("modelId"):
                self._fail("VALIDATION_FAILED", "modelId is required.", 422)
                return
            job = create_job("runtime.launch", body, ["validate", "test-machines", "start-workers", "start-host", "verify-api"])
            def add(state):
                state["jobs"].insert(0, job)
                state["runtime"]["state"] = "simulated-starting"
                add_log(state, "warning", "runtime", "Launch accepted in contract simulation mode; no process will be started.", jobId=job["id"])
                return job
            STORE.mutate(add)
            simulate_job(job["id"])
            self._ok(job, 202)
            return
        if parts == ["runtime", "stop"]:
            job = create_job("runtime.stop", body, ["drain-requests", "stop-host", "stop-workers", "verify-stopped"])
            def add(state):
                state["jobs"].insert(0, job)
                add_log(state, "warning", "runtime", "Stop accepted in contract simulation mode.", jobId=job["id"])
                return job
            STORE.mutate(add)
            simulate_job(job["id"])
            self._ok(job, 202)
            return
        self._fail("ROUTE_NOT_FOUND", "Unknown API route.", 404)

    def _serve_static(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        rel = parsed.path.lstrip("/") or "index.html"
        target = (WEB_ROOT / rel).resolve()
        if WEB_ROOT.resolve() not in target.parents and target != WEB_ROOT.resolve():
            self.send_error(HTTPStatus.FORBIDDEN)
            return
        if target.is_dir():
            target = target / "index.html"
        if not target.exists() or not target.is_file():
            if "." not in Path(rel).name:
                target = WEB_ROOT / "index.html"
            else:
                self.send_error(HTTPStatus.NOT_FOUND)
                return
        body = target.read_bytes()
        content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)


def main() -> None:
    parser = argparse.ArgumentParser(description="Letterblack Local Inference Workspace Phase 1 server")
    parser.add_argument("--host", default=os.environ.get("LB_HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("LB_PORT", "8088")))
    args = parser.parse_args()
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"Letterblack Phase 1 serving http://{args.host}:{args.port}")
    print("Runtime actions are contract simulations only. No llama.cpp process is started.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
