# Letterblack Local Inference Workspace — Phase 1 Contracts

This package freezes the control-plane API contract and serves the approved UX from the same dependency-free Python process.

## What Phase 1 provides

- Versioned `/api/v1` contract
- OpenAPI document and JSON schemas
- Persistent machine and profile registries
- Structured success/error envelopes with request IDs
- Background job model with phases, progress, evidence and errors
- Capability document that explicitly states what is implemented
- Real TCP reachability test for registered machine controller endpoints
- Contract simulations for RPC start/stop, model scans and runtime launch/stop
- Structured logs and placeholder telemetry contract
- Unit tests
- Existing UX served at `http://127.0.0.1:8088`

## Truthful limitation

**This phase does not start or stop llama.cpp or RPC processes.** Mutation endpoints return simulated jobs so the UI can be integrated against a stable contract before runtime authority is added.

## Run on Windows

Double-click `run.bat`, or:

```powershell
cd <extracted-folder>\Letterblack-Inference-Workspace-Phase1
py -3 -m backend.server --host 127.0.0.1 --port 8088
```

Open:

```text
http://127.0.0.1:8088
```

## Verify

```powershell
.\test.bat
```

Expected: 6 tests pass.

## Important API routes

```text
GET    /api/v1/capabilities
GET    /api/v1/system/status
GET    /api/v1/machines
POST   /api/v1/machines
PUT    /api/v1/machines/{id}
DELETE /api/v1/machines/{id}
POST   /api/v1/machines/{id}/test
POST   /api/v1/machines/{id}/rpc/start
POST   /api/v1/machines/{id}/rpc/stop
GET    /api/v1/models
POST   /api/v1/models/scan
GET    /api/v1/profiles
POST   /api/v1/profiles
POST   /api/v1/runtime/launch
POST   /api/v1/runtime/stop
GET    /api/v1/jobs
GET    /api/v1/jobs/{id}
GET    /api/v1/logs
GET    /api/v1/telemetry
GET    /api/v1/openapi.json
```

## State file

Runtime contract state persists in:

```text
data\state.json
```

Delete it only when you intentionally want to reset the Phase 1 registry.
