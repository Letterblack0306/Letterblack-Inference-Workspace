@echo off
setlocal
cd /d "%~dp0"
python -m unittest discover -s tests -p "test_*.py"
if errorlevel 1 exit /b %errorlevel%
python -m py_compile backend\*.py
if errorlevel 1 exit /b %errorlevel%
echo Phase 4 tests passed.
