# Letterblack Local Inference Workspace — Phase 4

Phase 4 adds a truthful compatibility gateway and request lifecycle on top of the Phase 3 runtime integration.

## Implemented

- OpenAI-compatible subset: `GET /v1/models`, `POST /v1/chat/completions`, `POST /v1/completions`, `POST /v1/embeddings`
- Ollama-compatible subset: `GET /api/tags`, `POST /api/chat`, `POST /api/generate`, `POST /api/embeddings`
- Streaming byte passthrough from the active llama-server
- Active request registry and bounded history
- Gateway drain gate before runtime shutdown
- Explicit rejection of unsupported compatibility routes
- Explicit 409 response when cancellation is requested after upstream dispatch
- `GET /api/v1/requests` and `GET /api/v1/gateway/status`
- `POST /api/v1/requests/{id}/cancel`

## Important compatibility boundary

This is not full OpenAI or Ollama parity. Routes listed above are forwarded to the active llama-server. Unsupported routes return `COMPATIBILITY_ROUTE_UNSUPPORTED`. Active request cancellation is not claimed because the stdlib transport cannot safely interrupt a request already dispatched upstream.

## Run

```powershell
.\run.bat
```

Open `http://127.0.0.1:8088`.

## Verify

```powershell
.\test.bat
```
