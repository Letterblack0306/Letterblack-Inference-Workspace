# Letterblack Local Inference Workspace — Phase 3

Phase 3 connects the Phase 2 workspace to constrained real runtime operations.

## Real operations

- Recursive `.gguf` model scanning from configured sources.
- TCP and controller-status machine tests.
- Worker RPC start/stop through a fixed HTTP controller contract.
- Local `llama-server(.exe)` launch with structured profile fields.
- RPC readiness and API port verification.
- Managed process logs and evidence-based Stop All.

## Security boundary

The backend never accepts an arbitrary shell command. It permits only:

1. controller status;
2. controller RPC start/stop;
3. local executable named `llama-server` or `llama-server.exe`;
4. structured arguments with reserved model/host/port fields protected from `extraArgs`.

## Expected worker controller contract

Defaults are configurable per machine under `controller.routes`.

- `GET /status`
- `POST /rpc/start` body `{ "port": 50052 }`
- `POST /rpc/stop` body `{ "port": 50052 }`

Each route returns JSON. The controller remains responsible for allowlisting the host and launching only its configured RPC executable.

## Run

```powershell
.\run.bat
```

Open `http://127.0.0.1:8088`.

## Test

```powershell
.\test.bat
```

## First real launch

1. Scan models with `POST /api/v1/models/scan` and a source path visible to the host service.
2. Create a profile whose `values` contains `executable`, `port`, `host`, and optional `rpcMachineIds`.
3. Ensure each selected worker controller is reachable and RPC is started.
4. Call `POST /api/v1/runtime/launch` with `modelId` and `profileId`.
5. Poll `/api/v1/jobs/{jobId}` until succeeded or failed.

Phase 3 does not yet implement OpenAI/Ollama gateway translation, GPU telemetry collection, request draining, or GGUF binary header parsing. Those remain later phases.
